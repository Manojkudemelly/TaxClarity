import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BookOpen, TrendingUp, Shield, Percent } from 'lucide-react';
import { taxSections, regimeComparison } from '@/data/taxKnowledge';

const TaxKnowledge = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 p-4">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 bg-gradient-primary rounded-xl shadow-elegant">
              <BookOpen className="h-8 w-8 text-primary-foreground" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-primary bg-clip-text text-transparent">
              Tax Knowledge Center
            </h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Complete guide to Indian Income Tax sections, deductions, and regime comparison for FY 2024-25
          </p>
        </div>

        <Tabs defaultValue="sections" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 lg:grid-cols-3 max-w-lg mx-auto">
            <TabsTrigger value="sections" className="flex items-center gap-2">
              <Percent className="h-4 w-4" />
              Tax Sections
            </TabsTrigger>
            <TabsTrigger value="comparison" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Regime Comparison
            </TabsTrigger>
          </TabsList>

          {/* Tax Sections */}
          <TabsContent value="sections" className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">Income Tax Deduction Sections</h2>
              <p className="text-muted-foreground">
                Detailed explanation of various tax deduction sections available under the old regime
              </p>
            </div>

            <div className="grid gap-6">
              {taxSections.map((section, index) => (
                <Card key={index} className="border-2 border-border/50 shadow-elegant hover:shadow-lg transition-smooth">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <CardTitle className="flex items-center gap-3">
                          <Badge variant="default" className="text-lg font-bold px-3 py-1">
                            Section {section.section}
                          </Badge>
                          <span className="text-xl">{section.title}</span>
                        </CardTitle>
                        <div className="flex items-center gap-4">
                          <Badge variant="outline" className="text-sm">
                            {section.limit}
                          </Badge>
                          <Badge 
                            variant={section.applicableRegime === "Old Regime Only" ? "destructive" : "default"}
                            className="text-sm"
                          >
                            {section.applicableRegime}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <CardDescription className="text-base leading-relaxed">
                      {section.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <h4 className="font-semibold text-primary">Eligibility:</h4>
                      <p className="text-muted-foreground">{section.eligibility}</p>
                    </div>
                    
                    <div className="space-y-3">
                      <h4 className="font-semibold text-primary">Examples & Coverage:</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {section.examples.map((example, exampleIndex) => (
                          <div 
                            key={exampleIndex}
                            className="flex items-center gap-2 p-2 bg-muted/30 rounded-lg"
                          >
                            <div className="w-2 h-2 bg-accent rounded-full flex-shrink-0" />
                            <span className="text-sm">{example}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Regime Comparison */}
          <TabsContent value="comparison" className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">New vs Old Tax Regime</h2>
              <p className="text-muted-foreground">
                Comprehensive comparison to help you choose the right tax regime
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* New Regime */}
              <Card className="border-2 border-primary/20 bg-gradient-to-br from-card to-primary/5 shadow-elegant">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <div className="p-2 bg-primary rounded-lg">
                      <Shield className="h-5 w-5 text-primary-foreground" />
                    </div>
                    {regimeComparison.newRegime.name}
                    <Badge variant="default">Default</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-3">
                    <h4 className="font-semibold text-primary">Key Features:</h4>
                    <ul className="space-y-2">
                      {regimeComparison.newRegime.features.map((feature, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-semibold text-success">Benefits:</h4>
                    <ul className="space-y-2">
                      {regimeComparison.newRegime.benefits.map((benefit, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <div className="w-1.5 h-1.5 bg-success rounded-full mt-2 flex-shrink-0" />
                          <span className="text-sm">{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-semibold text-destructive">Limitations:</h4>
                    <ul className="space-y-2">
                      {regimeComparison.newRegime.drawbacks.map((drawback, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <div className="w-1.5 h-1.5 bg-destructive rounded-full mt-2 flex-shrink-0" />
                          <span className="text-sm">{drawback}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>

              {/* Old Regime */}
              <Card className="border-2 border-secondary/50 bg-gradient-to-br from-card to-secondary/5 shadow-elegant">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <div className="p-2 bg-secondary rounded-lg">
                      <BookOpen className="h-5 w-5 text-secondary-foreground" />
                    </div>
                    {regimeComparison.oldRegime.name}
                    <Badge variant="secondary">Optional</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-3">
                    <h4 className="font-semibold text-primary">Key Features:</h4>
                    <ul className="space-y-2">
                      {regimeComparison.oldRegime.features.map((feature, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-semibold text-success">Benefits:</h4>
                    <ul className="space-y-2">
                      {regimeComparison.oldRegime.benefits.map((benefit, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <div className="w-1.5 h-1.5 bg-success rounded-full mt-2 flex-shrink-0" />
                          <span className="text-sm">{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-semibold text-destructive">Limitations:</h4>
                    <ul className="space-y-2">
                      {regimeComparison.oldRegime.drawbacks.map((drawback, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <div className="w-1.5 h-1.5 bg-destructive rounded-full mt-2 flex-shrink-0" />
                          <span className="text-sm">{drawback}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Tax Slabs Comparison */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
              <Card className="shadow-elegant">
                <CardHeader>
                  <CardTitle className="text-primary">New Regime Tax Slabs</CardTitle>
                  <CardDescription>FY 2024-25 (AY 2025-26)</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between py-2 border-b">
                      <span className="font-medium">Income Range</span>
                      <span className="font-medium">Tax Rate</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>₹0 - ₹3,00,000</span>
                      <span className="text-success font-medium">0%</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>₹3,00,001 - ₹6,00,000</span>
                      <span className="font-medium">5%</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>₹6,00,001 - ₹9,00,000</span>
                      <span className="font-medium">10%</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>₹9,00,001 - ₹12,00,000</span>
                      <span className="font-medium">15%</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>₹12,00,001 - ₹15,00,000</span>
                      <span className="font-medium">20%</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>Above ₹15,00,000</span>
                      <span className="text-destructive font-medium">30%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-elegant">
                <CardHeader>
                  <CardTitle className="text-primary">Old Regime Tax Slabs</CardTitle>
                  <CardDescription>FY 2024-25 (AY 2025-26)</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between py-2 border-b">
                      <span className="font-medium">Income Range</span>
                      <span className="font-medium">Tax Rate</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>₹0 - ₹2,50,000</span>
                      <span className="text-success font-medium">0%</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>₹2,50,001 - ₹5,00,000</span>
                      <span className="font-medium">5%</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>₹5,00,001 - ₹10,00,000</span>
                      <span className="font-medium">20%</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>Above ₹10,00,000</span>
                      <span className="text-destructive font-medium">30%</span>
                    </div>
                    <div className="pt-2 text-sm text-muted-foreground">
                      * Plus applicable deductions under various sections
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default TaxKnowledge;